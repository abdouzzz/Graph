/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sae_tp_etu;

/**
 *
 * @author educe
 */

import javax.swing.JDialog;
import org.graphstream.algorithm.generator.BarabasiAlbertGenerator;
import org.graphstream.algorithm.generator.Generator;
import org.graphstream.algorithm.generator.GridGenerator;
import org.graphstream.algorithm.generator.RandomGenerator;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;

/**
 *
 * @author Eric
 */
public class GrapheFabrique {
    
    static Graph createPersonalGraph()  
    {
        
        Graph g = null;
        return g;
        
    }    
    
      static Graph createChaine(int nb){
        
        Graph g = null;
        return g;
    }
    
    static public Graph createCycle(int nb)
    {
        Graph g = null;
        return g;
    }
    
    static Graph createRandom(int n, int avg){
        
        Graph g = null;
        return g;        
    }
    

    
  
    
    static public Graph createGrid(int dim1, int dim2, boolean torus)
    {
        Graph g = null;
        return g;
    }
    
    
    
}

